﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    class GameTester {

        static void Main(string[] args)
        {
            ConsoleApplication9.Horror alarming = new ConsoleApplication9.Horror();
            ConsoleApplication9.RPG lively = new ConsoleApplication9.RPG();
            Console.WriteLine();

        }
    }
}
