﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication9
{
    public class Games
    {

        public void scaryness(int scary)
        {
            fear = scary;
        }
        public void entertainment(int enjoyable)
        {
            fun = enjoyable;
        }
        protected int fear;
        protected int fun;
    }
}
