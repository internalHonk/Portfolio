﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace portalGame_
{
    public partial class tLevel1 : Form
    {
        public tLevel1()
        {
            InitializeComponent();
        }
    }
}
