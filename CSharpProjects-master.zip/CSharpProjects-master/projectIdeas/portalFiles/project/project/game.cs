﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project
{
    public partial class game : Form
    {
        private int playerX;
        private int playerY;
        private int speed = 3;
        private bool jump;
        private bool duck;
        private bool groundTouch;
        public game()
        {
            InitializeComponent();
        }

        private void game_Load(object sender, EventArgs e)
        {
            this.MaximizeBox = false;
            playerX = 84;
            playerY = 348;
            /*foreach (Object obj in game.ActiveForm)
            {
                obj.Velocity *= 0.5;
                obj.Velocity += GravityPerSecond * FrameTime;
                obj.Move(obj.Velocity);
            }*/
        }
    }
}
