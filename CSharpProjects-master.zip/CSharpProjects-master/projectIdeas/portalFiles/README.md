So if you are reading this it means you are browsing the Portal Relived images, animations, and maybe some possible beta versions of the game. DON'T DO ANYTHING WITH THIS STUFF.
