##WELCOME!!

the C# Dev group at its finest here. XD

We have decided on creating a Portal 1-2 mockup called "Portal Relived." Progress is slow; for art is time consuming and without it creating levels and other eleents in the game are delayed. As of this update, nearly all of the original elements have been implemented and somewhat worked with. At this point, we are wrapping up Phase 1 of planning, and beginning Stage 2 of development.

I pray to God we don't mess up.

###DISCLAIMER:
Any references to Portal and Portal 2 belong to and are trademarks of Valve, we have no relevance to these digital products.
